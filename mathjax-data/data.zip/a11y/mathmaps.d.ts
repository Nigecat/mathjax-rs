declare const MathMaps: Map<string, {
    [path: string]: any;
}>;
export default MathMaps;
