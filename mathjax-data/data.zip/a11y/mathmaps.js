"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MathMaps = new Map();
exports.default = MathMaps;
//# sourceMappingURL=mathmaps.js.map