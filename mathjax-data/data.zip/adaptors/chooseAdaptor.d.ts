import { liteAdaptor } from './liteAdaptor.js';
import { browserAdaptor } from './browserAdaptor.js';
export declare const chooseAdaptor: typeof browserAdaptor | typeof liteAdaptor;
