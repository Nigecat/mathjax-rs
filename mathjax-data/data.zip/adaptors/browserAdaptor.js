"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.browserAdaptor = void 0;
var HTMLAdaptor_js_1 = require("./HTMLAdaptor.js");
function browserAdaptor() {
    return new HTMLAdaptor_js_1.HTMLAdaptor(window);
}
exports.browserAdaptor = browserAdaptor;
//# sourceMappingURL=browserAdaptor.js.map