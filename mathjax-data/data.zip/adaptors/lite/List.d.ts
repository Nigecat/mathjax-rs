import { LiteNode } from './Element.js';
export declare class LiteList<N> {
    nodes: N[];
    constructor(children: N[]);
    append(node: N): void;
    [Symbol.iterator](): Iterator<LiteNode>;
}
