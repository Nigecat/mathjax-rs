import { LiteElement } from './Element.js';
export declare class LiteText {
    value: string;
    parent: LiteElement;
    get kind(): string;
    constructor(text?: string);
}
export declare class LiteComment extends LiteText {
    get kind(): string;
}
