import { PropertyList } from '../../Tree/Node.js';
import { AbstractMmlLayoutNode } from '../MmlNode.js';
export declare class MmlMpadded extends AbstractMmlLayoutNode {
    static defaults: PropertyList;
    get kind(): string;
}
