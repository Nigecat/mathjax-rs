import { MmlNodeClass } from './MmlNode.js';
export declare let MML: {
    [kind: string]: MmlNodeClass;
};
