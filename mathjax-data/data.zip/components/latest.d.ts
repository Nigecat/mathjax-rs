export declare function loadLatest(): void;
