import { CHTMLConstructor } from '../Wrapper.js';
declare const CHTMLms_base: import("../../common/Wrappers/ms.js").MsConstructor & CHTMLConstructor<any, any, any>;
export declare class CHTMLms<N, T, D> extends CHTMLms_base {
    static kind: string;
}
export {};
