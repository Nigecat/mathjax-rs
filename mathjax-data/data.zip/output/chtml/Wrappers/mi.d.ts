import { CHTMLConstructor } from '../Wrapper.js';
declare const CHTMLmi_base: import("../../common/Wrappers/mi.js").MiConstructor & CHTMLConstructor<any, any, any>;
export declare class CHTMLmi<N, T, D> extends CHTMLmi_base {
    static kind: string;
}
export {};
