import { CHTMLConstructor } from '../Wrapper.js';
declare const CHTMLTeXAtom_base: import("../../common/Wrappers/TeXAtom.js").TeXAtomConstructor & CHTMLConstructor<any, any, any>;
export declare class CHTMLTeXAtom<N, T, D> extends CHTMLTeXAtom_base {
    static kind: string;
    toCHTML(parent: N): void;
}
export {};
