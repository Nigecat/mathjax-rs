import { CHTMLConstructor } from '../Wrapper.js';
declare const CHTMLmfenced_base: import("../../common/Wrappers/mfenced.js").MfencedConstructor & CHTMLConstructor<any, any, any>;
export declare class CHTMLmfenced<N, T, D> extends CHTMLmfenced_base {
    static kind: string;
    toCHTML(parent: N): void;
}
export {};
