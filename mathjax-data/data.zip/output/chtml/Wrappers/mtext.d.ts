import { CHTMLConstructor } from '../Wrapper.js';
declare const CHTMLmtext_base: import("../../common/Wrappers/mtext.js").MtextConstructor & CHTMLConstructor<any, any, any>;
export declare class CHTMLmtext<N, T, D> extends CHTMLmtext_base {
    static kind: string;
}
export {};
