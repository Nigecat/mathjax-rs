import { CHTMLConstructor } from '../Wrapper.js';
declare const CHTMLmn_base: import("../../common/Wrappers/mn.js").MnConstructor & CHTMLConstructor<any, any, any>;
export declare class CHTMLmn<N, T, D> extends CHTMLmn_base {
    static kind: string;
}
export {};
