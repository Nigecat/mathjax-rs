export { script } from '../../../common/fonts/tex/script.js';
