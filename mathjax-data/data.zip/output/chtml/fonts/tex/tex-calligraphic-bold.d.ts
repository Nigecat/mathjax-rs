import { CHTMLCharMap } from '../../FontData.js';
export declare const texCalligraphicBold: CHTMLCharMap;
