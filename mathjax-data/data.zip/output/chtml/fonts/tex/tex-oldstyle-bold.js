"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.texOldstyleBold = void 0;
var tex_oldstyle_bold_js_1 = require("../../../common/fonts/tex/tex-oldstyle-bold.js");
Object.defineProperty(exports, "texOldstyleBold", { enumerable: true, get: function () { return tex_oldstyle_bold_js_1.texOldstyleBold; } });
//# sourceMappingURL=tex-oldstyle-bold.js.map