"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scriptBold = void 0;
var script_bold_js_1 = require("../../../common/fonts/tex/script-bold.js");
Object.defineProperty(exports, "scriptBold", { enumerable: true, get: function () { return script_bold_js_1.scriptBold; } });
//# sourceMappingURL=script-bold.js.map