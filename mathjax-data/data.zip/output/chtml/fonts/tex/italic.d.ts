import { CHTMLCharMap } from '../../FontData.js';
export declare const italic: CHTMLCharMap;
