import { CHTMLCharMap } from '../../FontData.js';
export declare const texVariant: CHTMLCharMap;
