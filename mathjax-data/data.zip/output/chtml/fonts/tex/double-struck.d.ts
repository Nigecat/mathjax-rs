export { doubleStruck } from '../../../common/fonts/tex/double-struck.js';
