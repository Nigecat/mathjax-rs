export { texOldstyleBold } from '../../../common/fonts/tex/tex-oldstyle-bold.js';
