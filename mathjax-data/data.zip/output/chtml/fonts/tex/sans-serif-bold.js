"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sansSerifBold = void 0;
var FontData_js_1 = require("../../FontData.js");
var sans_serif_bold_js_1 = require("../../../common/fonts/tex/sans-serif-bold.js");
exports.sansSerifBold = (0, FontData_js_1.AddCSS)(sans_serif_bold_js_1.sansSerifBold, {
    0x2015: { c: '\\2014' },
    0x2017: { c: '_' },
    0x2044: { c: '/' },
    0x2206: { c: '\\394' },
});
//# sourceMappingURL=sans-serif-bold.js.map