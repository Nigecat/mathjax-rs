"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.texOldstyle = void 0;
var tex_oldstyle_js_1 = require("../../../common/fonts/tex/tex-oldstyle.js");
Object.defineProperty(exports, "texOldstyle", { enumerable: true, get: function () { return tex_oldstyle_js_1.texOldstyle; } });
//# sourceMappingURL=tex-oldstyle.js.map