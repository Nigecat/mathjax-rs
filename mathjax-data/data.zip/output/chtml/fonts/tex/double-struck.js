"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.doubleStruck = void 0;
var double_struck_js_1 = require("../../../common/fonts/tex/double-struck.js");
Object.defineProperty(exports, "doubleStruck", { enumerable: true, get: function () { return double_struck_js_1.doubleStruck; } });
//# sourceMappingURL=double-struck.js.map