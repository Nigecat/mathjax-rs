export { texOldstyle } from '../../../common/fonts/tex/tex-oldstyle.js';
