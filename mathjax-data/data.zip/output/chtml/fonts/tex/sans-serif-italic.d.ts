import { CHTMLCharMap } from '../../FontData.js';
export declare const sansSerifItalic: CHTMLCharMap;
