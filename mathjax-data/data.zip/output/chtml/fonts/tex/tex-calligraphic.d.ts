export { texCalligraphic } from '../../../common/fonts/tex/tex-calligraphic.js';
