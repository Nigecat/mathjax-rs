export { texMathit } from '../../../common/fonts/tex/tex-mathit.js';
