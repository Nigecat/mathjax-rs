export { scriptBold } from '../../../common/fonts/tex/script-bold.js';
