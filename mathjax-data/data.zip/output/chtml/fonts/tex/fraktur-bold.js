"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.frakturBold = void 0;
var FontData_js_1 = require("../../FontData.js");
var fraktur_bold_js_1 = require("../../../common/fonts/tex/fraktur-bold.js");
exports.frakturBold = (0, FontData_js_1.AddCSS)(fraktur_bold_js_1.frakturBold, {
    0x2044: { c: '/' },
});
//# sourceMappingURL=fraktur-bold.js.map