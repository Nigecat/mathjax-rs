"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.texCalligraphicBold = void 0;
var FontData_js_1 = require("../../FontData.js");
var tex_calligraphic_bold_js_1 = require("../../../common/fonts/tex/tex-calligraphic-bold.js");
exports.texCalligraphicBold = (0, FontData_js_1.AddCSS)(tex_calligraphic_bold_js_1.texCalligraphicBold, {
    0x131: { f: 'B' },
    0x237: { f: 'B' },
});
//# sourceMappingURL=tex-calligraphic-bold.js.map