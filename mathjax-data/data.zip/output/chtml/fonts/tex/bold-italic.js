"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.boldItalic = void 0;
var FontData_js_1 = require("../../FontData.js");
var bold_italic_js_1 = require("../../../common/fonts/tex/bold-italic.js");
exports.boldItalic = (0, FontData_js_1.AddCSS)(bold_italic_js_1.boldItalic, {
    0x131: { f: 'B' },
    0x237: { f: 'B' },
    0x2044: { c: '/' },
    0x2206: { c: '\\394' },
    0x29F8: { c: '/' },
});
//# sourceMappingURL=bold-italic.js.map