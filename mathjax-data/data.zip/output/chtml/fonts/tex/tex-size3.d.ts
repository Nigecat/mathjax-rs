import { CHTMLCharMap } from '../../FontData.js';
export declare const texSize3: CHTMLCharMap;
