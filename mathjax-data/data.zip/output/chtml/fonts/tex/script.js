"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.script = void 0;
var script_js_1 = require("../../../common/fonts/tex/script.js");
Object.defineProperty(exports, "script", { enumerable: true, get: function () { return script_js_1.script; } });
//# sourceMappingURL=script.js.map