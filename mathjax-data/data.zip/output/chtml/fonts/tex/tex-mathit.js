"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.texMathit = void 0;
var tex_mathit_js_1 = require("../../../common/fonts/tex/tex-mathit.js");
Object.defineProperty(exports, "texMathit", { enumerable: true, get: function () { return tex_mathit_js_1.texMathit; } });
//# sourceMappingURL=tex-mathit.js.map