import { CHTMLCharMap } from '../../FontData.js';
export declare const sansSerif: CHTMLCharMap;
