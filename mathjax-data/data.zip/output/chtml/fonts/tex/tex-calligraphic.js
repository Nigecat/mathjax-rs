"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.texCalligraphic = void 0;
var tex_calligraphic_js_1 = require("../../../common/fonts/tex/tex-calligraphic.js");
Object.defineProperty(exports, "texCalligraphic", { enumerable: true, get: function () { return tex_calligraphic_js_1.texCalligraphic; } });
//# sourceMappingURL=tex-calligraphic.js.map