import { CheckType, BaseItem, StackItem } from '../StackItem.js';
export declare class BeginEnvItem extends BaseItem {
    get kind(): string;
    get isOpen(): boolean;
    checkItem(item: StackItem): CheckType;
}
