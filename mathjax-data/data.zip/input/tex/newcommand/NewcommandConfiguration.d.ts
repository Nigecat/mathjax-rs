import { Configuration } from '../Configuration.js';
import './NewcommandMappings.js';
export declare const NewcommandConfiguration: Configuration;
