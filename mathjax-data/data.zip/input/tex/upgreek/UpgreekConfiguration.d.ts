import { Configuration } from '../Configuration.js';
export declare const UpgreekConfiguration: Configuration;
