import { Configuration } from '../Configuration.js';
export declare const AutoloadConfiguration: Configuration;
