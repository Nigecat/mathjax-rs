import { Configuration } from '../Configuration.js';
import { ParseMethod } from '../Types.js';
export declare let ExtpfeilMethods: Record<string, ParseMethod>;
export declare const ExtpfeilConfiguration: Configuration;
