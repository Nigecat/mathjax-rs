import { Configuration } from '../Configuration.js';
export declare const ConfigMacrosConfiguration: Configuration;
