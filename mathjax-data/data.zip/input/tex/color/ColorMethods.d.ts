import { ParseMethod } from '../Types.js';
export declare const ColorMethods: Record<string, ParseMethod>;
