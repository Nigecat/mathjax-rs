export declare const COLORS: Map<string, string>;
