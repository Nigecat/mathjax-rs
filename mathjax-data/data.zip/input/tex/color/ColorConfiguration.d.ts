import { Configuration } from '../Configuration.js';
export declare const ColorConfiguration: Configuration;
