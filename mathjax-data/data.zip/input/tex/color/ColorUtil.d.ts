export declare class ColorModel {
    private userColors;
    private normalizeColor;
    getColor(model: string, def: string): string;
    private getColorByName;
    defineColor(model: string, name: string, def: string): void;
}
