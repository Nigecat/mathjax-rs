import { ParseMethod } from '../Types.js';
export declare const MathtoolsMethods: Record<string, ParseMethod>;
