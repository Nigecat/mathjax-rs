import { Configuration, ParserConfiguration } from '../Configuration.js';
import { TeX } from '../../tex.js';
export declare function tagformatConfig(config: ParserConfiguration, jax: TeX<any, any, any>): void;
export declare const TagFormatConfiguration: Configuration;
