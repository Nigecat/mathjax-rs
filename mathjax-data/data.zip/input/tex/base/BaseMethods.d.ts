import { ParseMethod } from '../Types.js';
declare let BaseMethods: Record<string, ParseMethod>;
export default BaseMethods;
