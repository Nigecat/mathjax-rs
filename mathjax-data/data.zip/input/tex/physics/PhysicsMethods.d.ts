import { ParseMethod } from '../Types.js';
declare let PhysicsMethods: Record<string, ParseMethod>;
export default PhysicsMethods;
