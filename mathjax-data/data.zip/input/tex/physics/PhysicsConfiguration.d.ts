import { Configuration } from '../Configuration.js';
import './PhysicsMappings.js';
export declare const PhysicsConfiguration: Configuration;
