import { Configuration } from '../Configuration.js';
import { ParseMethod } from '../Types.js';
export declare let VerbMethods: Record<string, ParseMethod>;
export declare const VerbConfiguration: Configuration;
