import { Configuration } from '../Configuration.js';
import { ParseMethod } from '../Types.js';
export declare let ActionMethods: Record<string, ParseMethod>;
export declare const ActionConfiguration: Configuration;
