import { CheckType, BaseItem, StackItem } from '../StackItem.js';
export declare class BraketItem extends BaseItem {
    get kind(): string;
    get isOpen(): boolean;
    checkItem(item: StackItem): CheckType;
    toMml(): import("../../../core/MmlTree/MmlNode.js").MmlNode;
}
