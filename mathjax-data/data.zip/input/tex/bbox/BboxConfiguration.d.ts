import { Configuration } from '../Configuration.js';
import { ParseMethod } from '../Types.js';
export declare let BboxMethods: Record<string, ParseMethod>;
export declare const BboxConfiguration: Configuration;
