import { Configuration } from '../Configuration.js';
export declare const GensymbConfiguration: Configuration;
