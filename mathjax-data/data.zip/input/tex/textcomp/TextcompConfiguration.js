"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextcompConfiguration = void 0;
var Configuration_js_1 = require("../Configuration.js");
require("./TextcompMappings.js");
exports.TextcompConfiguration = Configuration_js_1.Configuration.create('textcomp', {
    handler: { macro: ['textcomp-macros'] }
});
//# sourceMappingURL=TextcompConfiguration.js.map