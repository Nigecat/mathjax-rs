import { Configuration } from '../Configuration.js';
import ParseOptions from '../ParseOptions.js';
export declare function filterCenterOver({ data }: {
    data: ParseOptions;
}): void;
export declare const CenternotConfiguration: Configuration;
