import { Configuration } from '../Configuration.js';
export declare const NoUndefinedConfiguration: Configuration;
