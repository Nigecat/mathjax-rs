import { Configuration } from '../Configuration.js';
export declare const MhchemConfiguration: Configuration;
