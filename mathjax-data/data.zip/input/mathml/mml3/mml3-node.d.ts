import { MathDocument } from '../../../core/MathDocument.js';
export declare function createTransform<N, T, D>(): (node: N, doc: MathDocument<N, T, D>) => N;
